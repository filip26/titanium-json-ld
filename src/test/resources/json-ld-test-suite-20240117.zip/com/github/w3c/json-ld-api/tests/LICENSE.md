The JSON-LD Test Suite is covered by the dual-licensing approach described in
[LICENSES FOR W3C TEST SUITES](https://www.w3.org/Consortium/Legal/2008/04-testsuite-copyright.html).
